import React, { useEffect, useState } from 'react'
import { Routes, Route, Link, Navigate, useNavigate } from 'react-router-dom'
import { supabase } from './supabaseClient'
import Home from './pages/Home.jsx'
import Auth from './pages/Auth.jsx'
import Onboarding from './pages/Onboarding.jsx'
import Feed from './pages/Feed.jsx'
import NewPost from './pages/NewPost.jsx'
import PostDetail from './pages/PostDetail.jsx'
import AdminDirectory from './pages/AdminDirectory.jsx'

function Protected({ session, children }) {
  if (!session) return <Navigate to="/auth" replace />
  return children
}

export default function App() {
  const [session, setSession] = useState(null)
  const [profileReady, setProfileReady] = useState(false)
  const [isAdmin, setIsAdmin] = useState(false)
  const navigate = useNavigate()

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session))
    const { data: sub } = supabase.auth.onAuthStateChange((_event, sess) => {
      setSession(sess)
      setProfileReady(false)
      setIsAdmin(false)
    })
    return () => sub.subscription.unsubscribe()
  }, [])

  useEffect(() => {
    async function checkProfile() {
      if (!session?.user) return
      // Check profile exists
      const { data: prof, error } = await supabase
        .from('profiles')
        .select('user_id, home_zip')
        .eq('user_id', session.user.id)
        .maybeSingle()

      if (error) console.error(error)

      if (!prof) {
        setProfileReady(false)
        navigate('/onboarding', { replace: true })
        return
      }

      setProfileReady(true)

      // Check admin flag via RPC
      const { data: adminFlag } = await supabase.rpc('is_admin')
      setIsAdmin(Boolean(adminFlag))
    }
    checkProfile()
  }, [session?.user?.id])

  async function signOut() {
    await supabase.auth.signOut()
    navigate('/', { replace: true })
  }

  return (
    <>
      <div className="nav">
        <div className="nav-inner">
          <Link className="brand" to="/"><span>Surplox</span> MVP</Link>
          <div className="nav-links">
            {session && (
              <>
                <Link className="btn small" to="/feed">Feed</Link>
                <Link className="btn small" to="/new">New Post</Link>
                {isAdmin && <Link className="btn small primary" to="/admin">Directory</Link>}
                <button className="btn small danger" onClick={signOut}>Sign out</button>
              </>
            )}
            {!session && (
              <Link className="btn small primary" to="/auth">Sign in</Link>
            )}
          </div>
        </div>
      </div>

      <div className="container">
        <Routes>
          <Route path="/" element={<Home session={session} />} />
          <Route path="/auth" element={<Auth />} />
          <Route path="/onboarding" element={<Protected session={session}><Onboarding /></Protected>} />
          <Route path="/feed" element={<Protected session={session}><Feed /></Protected>} />
          <Route path="/new" element={<Protected session={session}><NewPost /></Protected>} />
          <Route path="/p/:id" element={<Protected session={session}><PostDetail /></Protected>} />
          <Route path="/admin" element={<Protected session={session}><AdminDirectory /></Protected>} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>

        <div className="footerNote">
          No DMs by design. Posts are public to members only (subs/laborers). Contact info is visible only to admin.
        </div>
      </div>
    </>
  )
}
