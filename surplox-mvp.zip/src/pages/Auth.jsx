import React, { useState } from 'react'
import { supabase } from '../supabaseClient'
import { useNavigate } from 'react-router-dom'

export default function Auth() {
  const [mode, setMode] = useState('signin') // signin | signup
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [msg, setMsg] = useState('')
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  async function handleAuth(e) {
    e.preventDefault()
    setMsg('')
    setLoading(true)
    try {
      if (mode === 'signup') {
        const { error } = await supabase.auth.signUp({ email, password })
        if (error) throw error
        setMsg('Check your email for a confirmation link, then come back and sign in.')
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password })
        if (error) throw error
        navigate('/onboarding', { replace: true })
      }
    } catch (err) {
      setMsg(err.message || 'Error')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="card" style={{ maxWidth: 520, margin: '0 auto' }}>
      <div className="h1">{mode === 'signup' ? 'Create account' : 'Sign in'}</div>
      <p className="muted">Members-only. Subs & laborers only. No contractors.</p>

      <form onSubmit={handleAuth} className="grid" style={{ gap: 10 }}>
        <div>
          <div className="muted" style={{ marginBottom: 6 }}>Email</div>
          <input className="input" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@email.com" />
        </div>
        <div>
          <div className="muted" style={{ marginBottom: 6 }}>Password</div>
          <input className="input" value={password} onChange={(e) => setPassword(e.target.value)} type="password" placeholder="••••••••" />
        </div>

        <button className="btn primary" disabled={loading}>
          {loading ? 'Working…' : (mode === 'signup' ? 'Sign up' : 'Sign in')}
        </button>
      </form>

      {msg && <p style={{ marginTop: 10 }} className="muted">{msg}</p>}

      <hr />
      <button className="btn" onClick={() => setMode(mode === 'signup' ? 'signin' : 'signup')}>
        Switch to {mode === 'signup' ? 'Sign in' : 'Create account'}
      </button>
    </div>
  )
}
