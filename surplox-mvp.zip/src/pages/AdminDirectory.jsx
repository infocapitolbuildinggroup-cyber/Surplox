import React, { useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'

export default function AdminDirectory() {
  const [isAdmin, setIsAdmin] = useState(false)
  const [rows, setRows] = useState([])
  const [trades, setTrades] = useState([])
  const [filters, setFilters] = useState({ tradeId: '', verified: '' })
  const [msg, setMsg] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function init() {
      setLoading(true)
      const { data: adminFlag } = await supabase.rpc('is_admin')
      setIsAdmin(Boolean(adminFlag))
      const { data: t } = await supabase.from('trades').select('id,name').order('name')
      setTrades(t || [])
      setLoading(false)
      if (!adminFlag) return
      await load()
    }
    init()
  }, [])

  async function load() {
    setMsg('')
    try {
      // Join profiles + contact_private (contact_private select is admin-only via RLS)
      const { data, error } = await supabase
        .from('profiles')
        .select(`
          user_id,
          display_name,
          travel_radius_miles,
          crew_size,
          bio,
          trades(name),
          contact_private(phone, email, city, notes, verified_level)
        `)
        .order('created_at', { ascending: false })
      if (error) throw error

      let d = data || []
      if (filters.tradeId) {
        const tradeName = trades.find(x => String(x.id) === String(filters.tradeId))?.name
        d = d.filter(r => r.trades?.name === tradeName)
      }
      if (filters.verified !== '') {
        d = d.filter(r => (r.contact_private?.verified_level ?? 0) === Number(filters.verified))
      }
      setRows(d)
    } catch (err) {
      setMsg(err.message || 'Error loading directory')
    }
  }

  function setF(k, v) { setFilters((f) => ({ ...f, [k]: v })) }

  async function updateVerified(user_id, level) {
    setMsg('')
    try {
      const { error } = await supabase.from('contact_private').update({ verified_level: level }).eq('user_id', user_id)
      if (error) throw error
      await load()
    } catch (err) {
      setMsg(err.message || 'Error updating')
    }
  }

  if (loading) return <div className="card">Loading…</div>

  if (!isAdmin) {
    return (
      <div className="card">
        <div className="h1">Admin only</div>
        <p className="muted">This page is restricted.</p>
      </div>
    )
  }

  return (
    <div className="grid" style={{ gap: 12 }}>
      <div className="card">
        <div className="h1">Private Directory (Admin)</div>
        <p className="muted">
          Only you can see contact info. Filter by trade and verified level.
        </p>

        <div className="grid two" style={{ marginTop: 10 }}>
          <div>
            <div className="muted" style={{ marginBottom: 6 }}>Trade</div>
            <select className="input" value={filters.tradeId} onChange={(e) => setF('tradeId', e.target.value)}>
              <option value="">All trades</option>
              {trades.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          </div>
          <div>
            <div className="muted" style={{ marginBottom: 6 }}>Verified level</div>
            <select className="input" value={filters.verified} onChange={(e) => setF('verified', e.target.value)}>
              <option value="">Any</option>
              <option value="0">0 Applied</option>
              <option value="1">1 Phone</option>
              <option value="2">2 Docs</option>
              <option value="3">3 Trusted</option>
            </select>
          </div>
        </div>

        <div style={{ marginTop: 10 }} className="row">
          <button className="btn primary" onClick={load}>Refresh</button>
        </div>

        {msg && <p className="muted" style={{ marginTop: 10 }}>{msg}</p>}
      </div>

      <div className="list">
        {rows.map(r => {
          const c = r.contact_private || {}
          return (
            <div key={r.user_id} className="card">
              <div className="postMeta">
                <span className="badge">{r.trades?.name || 'General'}</span>
                <span className="badge">Crew {r.crew_size ?? '-'}</span>
                <span className="badge">Travel {r.travel_radius_miles ?? '-'} mi</span>
                <span className="badge good">Verified {c.verified_level ?? 0}</span>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
                <div>
                  <div style={{ fontWeight: 800, fontSize: 16 }}>{r.display_name}</div>
                  <div className="muted" style={{ marginTop: 4 }}>
                    {c.city ? `${c.city} · ` : ''}{c.phone || 'No phone'} · {c.email || 'No email'}
                  </div>
                </div>
                <div className="row" style={{ flex: '0 0 auto' }}>
                  {[0,1,2,3].map(lvl => (
                    <button key={lvl} className="btn small" onClick={() => updateVerified(r.user_id, lvl)}>{lvl}</button>
                  ))}
                </div>
              </div>

              {r.bio && <p className="muted" style={{ marginTop: 8, whiteSpace: 'pre-wrap' }}>{r.bio}</p>}
              {c.notes && <p className="muted" style={{ marginTop: 8 }}><b>Notes:</b> {c.notes}</p>}
            </div>
          )
        })}
        {rows.length === 0 && <div className="card">No members yet.</div>}
      </div>
    </div>
  )
}
