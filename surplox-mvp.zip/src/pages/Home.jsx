import React from 'react'
import { Link } from 'react-router-dom'

export default function Home({ session }) {
  return (
    <div className="grid two">
      <div className="card">
        <div className="h1">Texas Trades Network (Private Directory + Public Forum)</div>
        <p className="muted">
          Surplox is a members-only space for subs and laborers to ask trade questions by location (ZIP + radius),
          organized by trade categories. The member directory is private to admin only.
        </p>
        <hr />
        {!session ? (
          <>
            <p>To get started:</p>
            <ol className="muted">
              <li>Create an account</li>
              <li>Pick your trade + set your home ZIP</li>
              <li>Ask questions within a local radius</li>
            </ol>
            <Link className="btn primary" to="/auth">Create account / Sign in</Link>
          </>
        ) : (
          <>
            <p>You are signed in.</p>
            <div className="row">
              <Link className="btn primary" to="/feed">Go to Feed</Link>
              <Link className="btn" to="/new">Create a Post</Link>
            </div>
          </>
        )}
      </div>

      <div className="card">
        <div className="h1">How local radius posts work</div>
        <p className="muted">
          When you create a post, you choose a <span className="kbd">ZIP</span> and <span className="kbd">radius (miles)</span>.
          Members see posts if they live within the post’s radius.
        </p>
        <hr />
        <p className="muted">
          Example: Post to <span className="kbd">76031</span> within <span className="kbd">100 miles</span>.
          Anyone whose home ZIP is within 100 miles of 76031 will see it in their feed.
        </p>
      </div>
    </div>
  )
}
