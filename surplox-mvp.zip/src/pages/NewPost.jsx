import React, { useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'
import { useNavigate } from 'react-router-dom'

export default function NewPost() {
  const [trades, setTrades] = useState([])
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState('')
  const [form, setForm] = useState({
    trade_id: '',
    title: '',
    body: '',
    center_zip: '',
    radius_miles: 50
  })
  const navigate = useNavigate()

  useEffect(() => {
    supabase.from('trades').select('id,name').order('name').then(({ data }) => setTrades(data || []))
  }, [])

  function setField(k, v) { setForm((f) => ({ ...f, [k]: v })) }

  async function create() {
    setSaving(true); setMsg('')
    try {
      const { data: sessionData } = await supabase.auth.getSession()
      const user = sessionData.session?.user
      if (!user) throw new Error('Not signed in')

      if (!form.title.trim()) throw new Error('Title is required')
      if (!form.body.trim()) throw new Error('Body is required')
      if (!/^[0-9]{5}$/.test(form.center_zip)) throw new Error('Enter a valid 5-digit ZIP')
      const rad = Number(form.radius_miles)
      if (!rad || rad < 1 || rad > 300) throw new Error('Radius must be between 1 and 300 miles')

      // Lookup ZIP in zipcodes
      const { data: z, error: zErr } = await supabase
        .from('zipcodes')
        .select('zip, point')
        .eq('zip', form.center_zip)
        .maybeSingle()
      if (zErr) throw zErr
      if (!z) throw new Error('ZIP not found in database. Admin must import ZIP dataset.')

      // Insert post. Note: center_point is geography; Supabase expects WKT or GeoJSON.
      // We'll pass as WKT "POINT(lon lat)" by selecting lat/lon instead of point.
      const { data: z2, error: z2Err } = await supabase
        .from('zipcodes')
        .select('lat, lon')
        .eq('zip', form.center_zip)
        .maybeSingle()
      if (z2Err) throw z2Err
      const wkt = `POINT(${z2.lon} ${z2.lat})`

      const { data: post, error: pErr } = await supabase
        .from('posts')
        .insert({
          author_id: user.id,
          trade_id: form.trade_id ? Number(form.trade_id) : null,
          title: form.title.trim(),
          body: form.body.trim(),
          center_zip: form.center_zip,
          center_point: wkt,
          radius_miles: rad
        })
        .select('id')
        .single()
      if (pErr) throw pErr

      navigate(`/p/${post.id}`, { replace: true })
    } catch (err) {
      setMsg(err.message || 'Error creating post')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="card" style={{ maxWidth: 860, margin: '0 auto' }}>
      <div className="h1">Create a Post</div>
      <p className="muted">
        Pick a trade category, write your question, then choose a ZIP + radius.
        Your post will be visible to members who live within that radius.
      </p>

      <div className="grid two">
        <div>
          <div className="muted" style={{ marginBottom: 6 }}>Trade category</div>
          <select className="input" value={form.trade_id} onChange={(e) => setField('trade_id', e.target.value)}>
            <option value="">General (no trade)</option>
            {trades.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
        </div>

        <div>
          <div className="muted" style={{ marginBottom: 6 }}>Radius (miles)</div>
          <input className="input" type="number" value={form.radius_miles} onChange={(e) => setField('radius_miles', e.target.value)} />
        </div>

        <div>
          <div className="muted" style={{ marginBottom: 6 }}>ZIP (center)</div>
          <input className="input" value={form.center_zip} onChange={(e) => setField('center_zip', e.target.value)} placeholder="76031" />
        </div>

        <div className="card" style={{ borderStyle: 'dashed' }}>
          <div className="badge">Example</div>
          <p className="muted" style={{ marginTop: 8 }}>
            ZIP <span className="kbd">76031</span> within <span className="kbd">100</span> miles
            reaches most of DFW south + surrounding areas.
          </p>
        </div>
      </div>

      <div style={{ marginTop: 10 }}>
        <div className="muted" style={{ marginBottom: 6 }}>Title</div>
        <input className="input" value={form.title} onChange={(e) => setField('title', e.target.value)} placeholder="Example: Best way to set bollards in rocky soil?" />
      </div>

      <div style={{ marginTop: 10 }}>
        <div className="muted" style={{ marginBottom: 6 }}>Body</div>
        <textarea className="input" value={form.body} onChange={(e) => setField('body', e.target.value)} placeholder="Describe the situation, constraints, and what you’ve tried." />
      </div>

      {msg && <p className="muted" style={{ marginTop: 10 }}>{msg}</p>}
      <hr />
      <button className="btn primary" onClick={create} disabled={saving}>
        {saving ? 'Posting…' : 'Post'}
      </button>
    </div>
  )
}
