import React, { useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'
import { useNavigate } from 'react-router-dom'

export default function Onboarding() {
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState('')
  const [trades, setTrades] = useState([])
  const [form, setForm] = useState({
    display_name: '',
    trade_id: '',
    home_zip: '',
    travel_radius_miles: 50,
    crew_size: 1,
    bio: '',
    phone: '',
    city: ''
  })
  const navigate = useNavigate()

  useEffect(() => {
    async function load() {
      setLoading(true)
      setMsg('')
      const { data: sessionData } = await supabase.auth.getSession()
      const user = sessionData.session?.user
      if (!user) { navigate('/auth', { replace: true }); return }

      // fetch trades
      const { data: t, error: tErr } = await supabase.from('trades').select('id, name').order('name')
      if (tErr) console.error(tErr)
      setTrades(t || [])

      // see if profile exists
      const { data: prof } = await supabase.from('profiles').select('*').eq('user_id', user.id).maybeSingle()
      if (prof) {
        setForm((f) => ({
          ...f,
          display_name: prof.display_name || '',
          trade_id: prof.trade_id || '',
          home_zip: prof.home_zip || '',
          travel_radius_miles: prof.travel_radius_miles ?? 50,
          crew_size: prof.crew_size ?? 1,
          bio: prof.bio || ''
        }))
        // load contact_private if exists
        const { data: cp } = await supabase.from('contact_private').select('*').eq('user_id', user.id).maybeSingle()
        if (cp) setForm((f) => ({ ...f, phone: cp.phone || '', city: cp.city || '' }))
      }
      setLoading(false)
    }
    load()
  }, [])

  function setField(k, v) { setForm((f) => ({ ...f, [k]: v })) }

  async function save() {
    setSaving(true)
    setMsg('')
    try {
      const { data: sessionData } = await supabase.auth.getSession()
      const user = sessionData.session?.user
      if (!user) throw new Error('Not signed in')

      if (!form.display_name.trim()) throw new Error('Display name is required')
      if (!form.trade_id) throw new Error('Select a trade')
      if (!/^[0-9]{5}$/.test(form.home_zip)) throw new Error('Enter a valid 5-digit ZIP')

      // Upsert profile
      const { error: pErr } = await supabase.from('profiles').upsert({
        user_id: user.id,
        display_name: form.display_name.trim(),
        trade_id: Number(form.trade_id),
        travel_radius_miles: Number(form.travel_radius_miles),
        crew_size: Number(form.crew_size),
        bio: form.bio
      })
      if (pErr) throw pErr

      // Set home zip + point via RPC
      const { error: zErr } = await supabase.rpc('set_my_home_zip', { p_zip: form.home_zip })
      if (zErr) throw zErr

      // Contact private (members can store; only admin can read)
      const { error: cErr } = await supabase.from('contact_private').upsert({
        user_id: user.id,
        phone: form.phone || null,
        email: user.email,
        city: form.city || null
      })
      if (cErr) throw cErr

      navigate('/feed', { replace: true })
    } catch (err) {
      setMsg(err.message || 'Error saving')
    } finally {
      setSaving(false)
    }
  }

  if (loading) return <div className="card">Loading…</div>

  return (
    <div className="card" style={{ maxWidth: 820, margin: '0 auto' }}>
      <div className="h1">Member Setup</div>
      <p className="muted">
        Set your trade + home ZIP. Your ZIP is used to show you local posts.
        Phone/email is stored privately and visible only to admin.
      </p>

      <div className="grid two">
        <div>
          <div className="muted" style={{ marginBottom: 6 }}>Display name</div>
          <input className="input" value={form.display_name} onChange={(e) => setField('display_name', e.target.value)} />
        </div>
        <div>
          <div className="muted" style={{ marginBottom: 6 }}>Trade</div>
          <select className="input" value={form.trade_id} onChange={(e) => setField('trade_id', e.target.value)}>
            <option value="">Select…</option>
            {trades.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
        </div>
        <div>
          <div className="muted" style={{ marginBottom: 6 }}>Home ZIP</div>
          <input className="input" value={form.home_zip} onChange={(e) => setField('home_zip', e.target.value)} placeholder="76031" />
          <div className="muted" style={{ marginTop: 6 }}>Requires ZIP data imported into Supabase.</div>
        </div>
        <div>
          <div className="muted" style={{ marginBottom: 6 }}>Travel radius (miles)</div>
          <input className="input" type="number" value={form.travel_radius_miles} onChange={(e) => setField('travel_radius_miles', e.target.value)} />
        </div>
        <div>
          <div className="muted" style={{ marginBottom: 6 }}>Crew size</div>
          <input className="input" type="number" value={form.crew_size} onChange={(e) => setField('crew_size', e.target.value)} />
        </div>
        <div>
          <div className="muted" style={{ marginBottom: 6 }}>City (optional)</div>
          <input className="input" value={form.city} onChange={(e) => setField('city', e.target.value)} placeholder="Cleburne" />
        </div>
      </div>

      <div style={{ marginTop: 10 }}>
        <div className="muted" style={{ marginBottom: 6 }}>Bio (optional)</div>
        <textarea className="input" value={form.bio} onChange={(e) => setField('bio', e.target.value)} placeholder="What kind of work do you do? What equipment do you have?" />
      </div>

      <div className="grid two" style={{ marginTop: 10 }}>
        <div>
          <div className="muted" style={{ marginBottom: 6 }}>Phone (stored privately)</div>
          <input className="input" value={form.phone} onChange={(e) => setField('phone', e.target.value)} placeholder="optional" />
        </div>
        <div className="card" style={{ borderStyle: 'dashed' }}>
          <div className="badge good">Privacy</div>
          <p className="muted" style={{ marginTop: 8 }}>
            Members cannot see your phone/email. Only admin (CBG) can.
          </p>
        </div>
      </div>

      {msg && <p className="muted" style={{ marginTop: 10 }}>{msg}</p>}
      <hr />
      <button className="btn primary" onClick={save} disabled={saving}>
        {saving ? 'Saving…' : 'Save & Continue'}
      </button>
    </div>
  )
}
