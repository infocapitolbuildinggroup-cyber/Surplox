import React, { useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'
import { useParams, Link } from 'react-router-dom'

function timeAgo(ts) {
  const d = new Date(ts)
  const diff = (Date.now() - d.getTime()) / 1000
  if (diff < 60) return `${Math.floor(diff)}s ago`
  if (diff < 3600) return `${Math.floor(diff/60)}m ago`
  if (diff < 86400) return `${Math.floor(diff/3600)}h ago`
  return `${Math.floor(diff/86400)}d ago`
}

export default function PostDetail() {
  const { id } = useParams()
  const [post, setPost] = useState(null)
  const [comments, setComments] = useState([])
  const [score, setScore] = useState(0)
  const [myVote, setMyVote] = useState(0)
  const [newComment, setNewComment] = useState('')
  const [msg, setMsg] = useState('')
  const [loading, setLoading] = useState(true)

  async function loadAll() {
    setLoading(true); setMsg('')
    try {
      const { data: p, error: pErr } = await supabase
        .from('posts')
        .select('id,title,body,center_zip,radius_miles,created_at,trade_id,trades(name),author_id,profiles(display_name)')
        .eq('id', id)
        .single()
      if (pErr) throw pErr
      setPost({
        ...p,
        trade_name: p.trades?.name || 'General',
        author_name: p.profiles?.display_name || 'Unknown'
      })

      const { data: c, error: cErr } = await supabase
        .from('comments')
        .select('id,body,created_at,author_id,profiles(display_name)')
        .eq('post_id', id)
        .order('created_at', { ascending: true })
      if (cErr) throw cErr
      setComments((c || []).map(x => ({ ...x, author_name: x.profiles?.display_name || 'Unknown' })))

      const { data: v, error: vErr } = await supabase
        .from('votes')
        .select('value, voter_id')
        .eq('post_id', id)
      if (vErr) throw vErr
      const s = (v || []).reduce((a, r) => a + r.value, 0)
      setScore(s)

      const { data: sessionData } = await supabase.auth.getSession()
      const uid = sessionData.session?.user?.id
      const mine = (v || []).find(r => r.voter_id === uid)?.value || 0
      setMyVote(mine)
    } catch (err) {
      setMsg(err.message || 'Error loading post')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { loadAll() }, [id])

  async function vote(val) {
    setMsg('')
    try {
      const { data: sessionData } = await supabase.auth.getSession()
      const uid = sessionData.session?.user?.id
      if (!uid) throw new Error('Not signed in')
      const newVal = (myVote === val) ? 0 : val

      if (newVal === 0) {
        // delete vote
        const { error } = await supabase.from('votes').delete().eq('post_id', id).eq('voter_id', uid)
        if (error) throw error
      } else {
        const { error } = await supabase.from('votes').upsert({ post_id: id, voter_id: uid, value: newVal })
        if (error) throw error
      }
      await loadAll()
    } catch (err) {
      setMsg(err.message || 'Vote error')
    }
  }

  async function addComment() {
    setMsg('')
    try {
      if (!newComment.trim()) return
      const { data: sessionData } = await supabase.auth.getSession()
      const uid = sessionData.session?.user?.id
      if (!uid) throw new Error('Not signed in')

      const { error } = await supabase.from('comments').insert({
        post_id: id,
        author_id: uid,
        body: newComment.trim()
      })
      if (error) throw error
      setNewComment('')
      await loadAll()
    } catch (err) {
      setMsg(err.message || 'Comment error')
    }
  }

  if (loading) return <div className="card">Loading…</div>
  if (!post) return <div className="card">Post not found.</div>

  return (
    <div className="grid" style={{ gap: 12 }}>
      <div className="card">
        <div className="postMeta">
          <span className="badge">{post.trade_name}</span>
          <span>ZIP <span className="kbd">{post.center_zip}</span> · {post.radius_miles} mi</span>
          <span>·</span>
          <span>by {post.author_name}</span>
          <span>·</span>
          <span>{timeAgo(post.created_at)}</span>
        </div>

        <h2 style={{ margin: '10px 0 6px' }}>{post.title}</h2>
        <p className="muted" style={{ whiteSpace: 'pre-wrap' }}>{post.body}</p>

        <hr />
        <div className="row" style={{ alignItems: 'center' }}>
          <div className="voteBox">
            <button className="btn small" onClick={() => vote(1)}>{myVote === 1 ? '▲ Upvoted' : '▲ Upvote'}</button>
            <div className="score">{score}</div>
            <button className="btn small" onClick={() => vote(-1)}>{myVote === -1 ? '▼ Downvoted' : '▼ Downvote'}</button>
          </div>
          <div style={{ textAlign: 'right' }}>
            <Link className="btn small" to="/feed">Back to feed</Link>
          </div>
        </div>

        {msg && <p className="muted" style={{ marginTop: 10 }}>{msg}</p>}
      </div>

      <div className="card">
        <div className="h1" style={{ fontSize: 20 }}>Comments ({comments.length})</div>
        <div className="grid" style={{ gap: 10 }}>
          {comments.map(c => (
            <div key={c.id} className="card" style={{ background: '#0f1118' }}>
              <div className="postMeta">
                <span>by {c.author_name}</span>
                <span>·</span>
                <span>{timeAgo(c.created_at)}</span>
              </div>
              <div style={{ whiteSpace: 'pre-wrap' }}>{c.body}</div>
            </div>
          ))}
          {comments.length === 0 && <div className="muted">No comments yet. Be the first.</div>}
        </div>

        <hr />
        <div className="muted" style={{ marginBottom: 6 }}>Add a comment</div>
        <textarea className="input" value={newComment} onChange={(e) => setNewComment(e.target.value)} placeholder="Write your reply…" />
        <div style={{ marginTop: 10 }}>
          <button className="btn primary" onClick={addComment}>Post comment</button>
        </div>
      </div>
    </div>
  )
}
