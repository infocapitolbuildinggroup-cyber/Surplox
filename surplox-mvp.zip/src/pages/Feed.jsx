import React, { useEffect, useMemo, useState } from 'react'
import { supabase } from '../supabaseClient'
import { Link } from 'react-router-dom'

function timeAgo(ts) {
  const d = new Date(ts)
  const diff = (Date.now() - d.getTime()) / 1000
  if (diff < 60) return `${Math.floor(diff)}s ago`
  if (diff < 3600) return `${Math.floor(diff/60)}m ago`
  if (diff < 86400) return `${Math.floor(diff/3600)}h ago`
  return `${Math.floor(diff/86400)}d ago`
}

export default function Feed() {
  const [posts, setPosts] = useState([])
  const [profile, setProfile] = useState(null)
  const [q, setQ] = useState('')
  const [trades, setTrades] = useState([])
  const [tradeId, setTradeId] = useState('')
  const [loading, setLoading] = useState(true)
  const [msg, setMsg] = useState('')

  async function loadProfile() {
    const { data: sessionData } = await supabase.auth.getSession()
    const user = sessionData.session?.user
    if (!user) return
    const { data } = await supabase.from('profiles').select('display_name, home_zip').eq('user_id', user.id).maybeSingle()
    setProfile(data || null)
  }

  async function loadTrades() {
    const { data } = await supabase.from('trades').select('id,name').order('name')
    setTrades(data || [])
  }

  async function loadPosts() {
    setLoading(true)
    setMsg('')
    try {
      // If search query, use RPC search, else get near me feed
      if (q.trim()) {
        const { data, error } = await supabase.rpc('search_posts_near_me', {
          p_q: q.trim(),
          p_trade_id: tradeId ? Number(tradeId) : null,
          p_limit: 50,
          p_offset: 0
        })
        if (error) throw error
        setPosts(data || [])
      } else {
        const { data, error } = await supabase.rpc('get_posts_near_me', {
          p_limit: 50,
          p_offset: 0
        })
        if (error) throw error
        // client-side trade filter if chosen and no query
        const filtered = tradeId ? (data || []).filter(p => String(p.trade_id || '') === String(tradeId)) : (data || [])
        setPosts(filtered)
      }
    } catch (err) {
      setMsg(err.message || 'Error loading posts. Did you set your home ZIP and import ZIP data?')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadProfile()
    loadTrades()
  }, [])

  useEffect(() => {
    loadPosts()
  }, [q, tradeId])

  return (
    <div className="grid" style={{ gap: 12 }}>
      <div className="card">
        <div className="h1">Feed near you</div>
        <p className="muted">
          {profile?.home_zip ? (
            <>Showing posts based on your home ZIP <span className="kbd">{profile.home_zip}</span>.</>
          ) : (
            <>Set your home ZIP in onboarding so you can see local posts.</>
          )}
        </p>

        <div className="grid two" style={{ marginTop: 10 }}>
          <div>
            <div className="muted" style={{ marginBottom: 6 }}>Search</div>
            <input className="input" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search titles and posts…" />
          </div>
          <div>
            <div className="muted" style={{ marginBottom: 6 }}>Trade category</div>
            <select className="input" value={tradeId} onChange={(e) => setTradeId(e.target.value)}>
              <option value="">All trades</option>
              {trades.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          </div>
        </div>

        <div style={{ marginTop: 10 }}>
          <Link className="btn primary" to="/new">Create a Post</Link>
        </div>

        {msg && <p className="muted" style={{ marginTop: 10 }}>{msg}</p>}
      </div>

      <div className="list">
        {loading && <div className="card">Loading…</div>}
        {!loading && posts.length === 0 && <div className="card">No posts yet in your area. Create the first one.</div>}

        {!loading && posts.map(p => (
          <div key={p.id} className="card">
            <div className="postMeta">
              <span className="badge">{p.trade_name || 'General'}</span>
              <span>ZIP <span className="kbd">{p.center_zip}</span> · {p.radius_miles} mi</span>
              <span>·</span>
              <span>by {p.author_name}</span>
              <span>·</span>
              <span>{timeAgo(p.created_at)}</span>
            </div>
            <h3 className="postTitle">
              <Link to={`/p/${p.id}`}>{p.title}</Link>
            </h3>
            <p className="muted" style={{ marginTop: 0 }}>
              {p.body.length > 220 ? p.body.slice(0, 220) + '…' : p.body}
            </p>
            <div className="postMeta">
              <span className="voteBox">
                <span className="badge good">Score {p.score}</span>
                <span className="badge">{p.comment_count} comments</span>
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
